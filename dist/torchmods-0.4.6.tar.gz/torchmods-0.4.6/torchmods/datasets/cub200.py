
class CUB200():
    def __init__(self):
        raise NotImplementedError
