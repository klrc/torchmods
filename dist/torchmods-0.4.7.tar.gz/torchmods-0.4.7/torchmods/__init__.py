from .device import Device
from .device import connect as connect_device
from .device.ssh import open as ssh
