from .device import Device, connect
