from .flickr_ldl import FlickrDataset
from .salicon import SALICONDataset
