from .dataset_collection import *
from .cub200 import *
from .flickr_ldl import *
from .salicon import *
